<?php
//for debugging
echo "aaaaaaaaaa";
$a=implode("---",$_REQUEST);
var_dump($_REQUEST);
echo $a;
print_r($_POST);

?>